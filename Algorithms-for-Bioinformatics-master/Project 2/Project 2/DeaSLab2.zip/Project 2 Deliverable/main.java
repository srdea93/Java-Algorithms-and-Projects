package dea_project2;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/*
 * Main driver portion of the program. It will read input data sets line by line. Each line
 * will be processed into the 11 combinations required and output the data to an output file.
 * The output file will also include an efficiency calculation, a load factor, the number of collisions
 * that occurred, and the number of failed hashes. This program will demonstrate my implementation
 * of a hash table using various hashing functions using division as well as my own hashing
 * function that revolves around using radix addition. Additionally, this program demonstrates collision
 * handling using linear and quadratic probing as well as open addressing chaining. It also demonstrates
 * the differences in hashing between bucket sizes of 1 and 3. This program runs through 3 various input
 * files that I have generated, one of the normal input required by the assignment, one that has a large
 * amount of input (greater than the number of slots in the table), and one that is a completely empty file.
 */


public class main {
	
	/*
	 * This method is meant to take input specified in the main function and return a string of the hash table outputs
	 * complete with the hash function, the type of resolution employed, and the table itself formatted in either buckets
	 * of size 1 with 5 data values across or bucket size 3 with 3 data values across.
	 */
	public static String printHashTable(File file, hashTable table, int modulo, int resolution, int bucketSize) {
		String hashTableOutput = "";
		String resolutionStr = "";
		if(resolution == 1) {
			resolutionStr = "Linear";
		}
		if(resolution == 2) {
			resolutionStr = "Quadratic";
		}
		if(resolution == 3) {
			resolutionStr = "Chaining";
		}
		hashTableOutput = "Input File: " + file +"\n";
		
		if(modulo > 0) {
			hashTableOutput = hashTableOutput + "Modulo: " + modulo + "\n";
		}
		else {
			hashTableOutput = hashTableOutput + "My Hash\n";
		}
		
		hashTableOutput = hashTableOutput + "Resolution: " + resolutionStr + "\n";
		int bucketCounter = 0;
		String lineOutput = "";
		
		if(bucketSize == 1) {
			lineOutput = "Buckets " + bucketCounter + "-" + (bucketCounter+4) + ": ";
			lineOutput = String.format("%1$-17s", lineOutput);
			// Print out table to sys.out & write to output file.
			for(int k = 1; k <= table.getSize(); k++) {
				
				if(k%5 == 0 && k > 4) {
					if(((table.getTable()[k-1])) == -1) {
						lineOutput = lineOutput + String.format("%-6s", "XXXXX") + " ";
					}
					else {
						lineOutput = lineOutput + String.format("%-6s", String.format("%05d", table.getTable()[k-1])) + " ";
					}
					
					hashTableOutput = hashTableOutput + lineOutput + "\n";
					bucketCounter += 5;
					lineOutput = "Buckets " + bucketCounter + "-" + (bucketCounter+4) + ": ";
					lineOutput = String.format("%1$-17s", lineOutput);
//					System.out.print(table1.getTable()[i] + " ");
				}
				else {
					if(((table.getTable()[k-1])) == -1){
						lineOutput = lineOutput + String.format("%-6s", "XXXXX") + " ";
					}
					else {
						lineOutput = lineOutput + String.format("%-6s", String.format("%05d", table.getTable()[k-1])) + " ";
//						System.out.print(table1.getTable()[i] + " ");
					}
					
				}
			}
		}
		else {
			lineOutput = "Buckets " + bucketCounter + ": ";
			lineOutput = String.format("%1$-17s", lineOutput);
			
			for(int k = 1; k <= table.getSize(); k++) {
				
				if(k%3 == 0 && k > 2) {
					if(((table.getTable()[k-1])) == -1) {
						lineOutput = lineOutput + String.format("%-6s", "XXXXX") + " ";
					}
					else {
						lineOutput = lineOutput + String.format("%-6s", String.format("%05d", table.getTable()[k-1])) + " ";
					}
					hashTableOutput = hashTableOutput + lineOutput + "\n";
					bucketCounter += 1;
					lineOutput = "Buckets " + bucketCounter + ": ";
					lineOutput = String.format("%1$-17s", lineOutput);
//					System.out.print(table1.getTable()[i] + " ");
				}
				else {
					if(((table.getTable()[k-1])) == -1){
						lineOutput = lineOutput + String.format("%-6s", "XXXXX") + " ";
					}
					else {
						lineOutput = lineOutput + String.format("%-6s", String.format("%05d", table.getTable()[k-1])) + " ";
//						System.out.print(table1.getTable()[i] + " ");
					}
					
				}
			}
		}
		
		
		// Print out collisions, load factor
		String sizeStr = "Size: " + table.getSize();
		String occStr = "Occupancy: " + table.getOccupancy();
		String lf = "Load Factor: " + table.calcLoadFactor();
		String col = "Collisions: " + table.getCollisions();
		String fh = "Failed Hashes: " + table.getFailedHashes();

		hashTableOutput = hashTableOutput + sizeStr + "\n";
		hashTableOutput = hashTableOutput + occStr + "\n";
		hashTableOutput = hashTableOutput + lf + "\n";
		hashTableOutput = hashTableOutput + col + "\n";
		hashTableOutput = hashTableOutput + fh + "\n";
		hashTableOutput = hashTableOutput + "\n";
		
		
		return hashTableOutput;
	}
	
	/*
	 * This method is to take a specified output file in main to write the printed output from printHashTable
	 * into the output file.
	 */
	
	public static void writeHashTable(String hashTableOutput, File outfile) {
		FileWriter fr = null;
		
		// Use FileWriter to write matrixOutput to file
		try {
			fr = new FileWriter(outfile, true);
			fr.write(hashTableOutput);
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		finally {
			try {
				fr.close();
			}
			catch (IOException e) {
				e.printStackTrace();
			}
		}
	}


	public static void main(String[] args) throws FileNotFoundException{
		// Iterate through each input file that is specified by runtime parameters
		// Normal input
		File infile = new File(args[0]);
		
		// Large input
		File infile2 = new File(args[2]);
		
		// Empty input
		File infile3 = new File(args[3]);
		
		// Check if output file is already present 
		File outfile = new File(args[1]);
		if(outfile.exists()) {
			outfile.delete();
			try {
				outfile.createNewFile();
			}
			catch(IOException e) {
				e.printStackTrace();
			}
		}
		
		File fileList[] = new File[] {infile, infile2, infile3};
		// For modulo methods, bucket size 1, and all 3 types of collision handling
		int moduloList[] = new int[] {120, 113};
		int probingList[] = new int[] {1, 2, 3}; 
		int probingListBS3[] = new int[] {1, 2};
		
		for(int l = 0; l < 3; l++) {
			for(int i = 0; i < 2; i++) {
				for (int j = 0; j < 3; j++) {
					try{
						Scanner scanner = new Scanner(fileList[l]);
						
						// Create a hashtable for this iteration
						hashTable table = new hashTable(120);
						int modulo = moduloList[i];
						int resolutionValue = probingList[j];
						int bucketSize = 1;
						String resolutionStr = "";
						if(resolutionValue == 1) {
							resolutionStr = "Linear";
						}
						if(resolutionValue == 2) {
							resolutionStr = "Quadratic";
						}
						if(resolutionValue == 3) {
							resolutionStr = "Chaining";
						}
						
						// Parse through the input files line by line to retrieve the next hash key
						while(scanner.hasNextLine()) {
							// Grabs the next integer in the input file
							int key = scanner.nextInt();
							// Operation on the key
							table.hashInsert(0, key, modulo, resolutionValue, bucketSize);
						}
						
						// Only run this section if resolutionValue == 3 -- chaining to fill table before print
						if(resolutionValue == 3) {
							table.fillTableFromChain();
						}

						String hashTableOutput = printHashTable(fileList[l], table, modulo, resolutionValue, bucketSize);
						// Print the output hash tables
//						System.out.println(hashTableOutput);
						
						// Write the output to the output file
						writeHashTable(hashTableOutput, outfile);
					}
					catch (IOException e) {
						e.printStackTrace();
					}
					
				}
			}
			
			// For modulo 41 methods, bucket size 3, linear and quadratic probing
			for (int j = 0; j < 2; j++) {
				try{
					Scanner scanner = new Scanner(fileList[l]);
					
					// Create a hashtable for this iteration
					hashTable table = new hashTable(120);
					int modulo = 41;
					int resolutionValue = probingListBS3[j];
					int bucketSize = 3;
					String resolutionStr = "";
					if(resolutionValue == 1) {
						resolutionStr = "Linear";
					}
					if(resolutionValue == 2) {
						resolutionStr = "Quadratic";
					}
					if(resolutionValue == 3) {
						resolutionStr = "Chaining";
					}

					
					// Parse through the input files line by line to retrieve the next hash key
					while(scanner.hasNextLine()) {
						// Grabs the next integer in the input file
						int key = scanner.nextInt();
						// Operation on the key
						table.hashInsert(0, key, modulo, resolutionValue, bucketSize);
					}

					String hashTableOutput = printHashTable(fileList[l], table, modulo, resolutionValue, bucketSize);
					// Print the output hash tables
//					System.out.println(hashTableOutput);
					
					// Write the output to the output file
					writeHashTable(hashTableOutput, outfile);
				}
				catch (IOException e) {
					e.printStackTrace();
				}
			}
			
			// For my hash method, bucket size 1, all three types of collision handling
			for (int j = 0; j < 3; j++) {
				try {
					Scanner scanner = new Scanner(fileList[l]);
					
					hashTable table = new hashTable(120);
					int modulo = 0;
					int resolutionValue = probingList[j];
					int bucketSize = 1;
					String resolutionStr = "";
					if(resolutionValue == 1) {
						resolutionStr = "Linear";
					}
					if(resolutionValue == 2) {
						resolutionStr = "Quadratic";
					}
					if(resolutionValue == 3) {
						resolutionStr = "Chaining";
					}
					
					// Parse through the input files line by line to retrieve the next hash key
					while(scanner.hasNextLine()) {
						// Grabs the next integer in the input file
						int key = scanner.nextInt();
						// Operation on the key
						table.hashInsert(1, key, modulo, resolutionValue, bucketSize);
					}
					
					// Only run this section if resolutionValue == 3 -- chaining to fill table before print
					if(resolutionValue == 3) {
						table.fillTableFromChain();
					}
					
					String hashTableOutput = printHashTable(fileList[l], table, modulo, resolutionValue, bucketSize);
					// Print the output hash tables
//					System.out.println(hashTableOutput);
					
					// Write the output to the output file
					writeHashTable(hashTableOutput, outfile);
				}
				catch(IOException e) {
					e.printStackTrace();
				}
			}
		}

	}

}
