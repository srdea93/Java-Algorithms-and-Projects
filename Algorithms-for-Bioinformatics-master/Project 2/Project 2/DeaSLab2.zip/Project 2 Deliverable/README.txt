README
Steven Dea
Spring 2020

This program was written using Java 11.0.6 and written using the Eclipse IDE.

This program is designed to take a(n) input file(s) containing integer values spaced by new lines. It will then run each of these integer values through various hashing functions and collision resolution methods to insert into a hash table data structure. It will then output the resulting tables in the output file.

Input files: input.txt, input_large.txt, input_empty.txt
Output file: outfile.txt

Command line used to run: java dea_project2.main input.txt outfile.txt input_large.txt input_empty.txt