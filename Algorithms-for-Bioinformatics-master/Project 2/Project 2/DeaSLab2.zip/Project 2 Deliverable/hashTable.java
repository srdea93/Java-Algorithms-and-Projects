package dea_project2;

import java.util.*;

/*
 * Module to implement the given hash functions and my own hash function provided in the pdf
 * Provided functions:
 * It should take in parameters of the modulo: 120, 113 and the bucket size: 1
 * Bucket size of 1 means each position in the table is available to be inserted via hashing
 * It must also implement 3 different methods of collision handling: linear, quadratic, chaining
 * Linear: if there is collision, find next open space and insert there
 * Quadratic: if there is collision, square variable k and insert there, k == k^2
 * Chaining:
 * 
 * Keep track of collision counter as well as occupancy counter to determine efficiency
 * 
 * 
 * For module: 41, buckets of size: 3 with only linear and quadratic probing
 * 
 * My hash function: 
 * Cannot use a form of division to hash
 * Possible ideas: 
 */

public class hashTable {
	private int size = 120;
	private int[] table = new int[this.size];
	
	// Hashtable efficiency - how many collisions occur that need to be resolved?
	private int collisions = 0;
	
	// Used to calculate the load factor. Every successful insertion into hashtable increases this by 1
	private int occupancy = 0;
	
	// Used to keep track of the hashes that have failed to be inserted into the table
	private int failedHashes = 0;
	
	private LinkedList<Integer> linkedList = new LinkedList<Integer>();
	
	// Initialize hashTable with no parameters
	public hashTable() {
		size = 120;
		table = new int[this.size];
		for (int i = 0; i < this.size; i++) {
			table[i] = -1;
		}
	}
	
	// Initialize hashTable with a size and a bucketSize
	public hashTable(int size) {
		this.size = size;
		this.table = new int[size];
		// Initialize whole array with values of -1 to represent it being empty
		for (int i = 0; i < this.size; i++) {
			table[i] = -1;
		}
	}
	
	public int getSize() {
		return this.size;
	}
	
	public void setSize(int size) {
		this.size = size;
		this.table = new int[size];
	}
	
	public int[] getTable() {
		return this.table;
	}
	
	public int getCollisions() {
		return this.collisions;
	}
	
	public int getOccupancy() {
		return this.occupancy;
	}
	
	public int getFailedHashes() {
		return this.failedHashes;
	}
	
	// Method to calculate the load factor of this hash table instance once all keys have been inserted
	public double calcLoadFactor() {
		double loadFactor = 0;
		double occupancy = new Double(this.occupancy);
		double size = new Double(this.size);
		loadFactor = occupancy/size;
		return loadFactor;
	}
	/*
	 * Function to check if a particular location in the table is empty.
	 * This function takes in a hash and sees if the value stored at the location is 0
	 * (which is null for Java int arrays). If it is 0, then it returns that the location
	 * is empty. If it is anythign else, it returns false that the locations is not empty.
	 */
	public boolean isEmpty(int location) {
		// Java int arrays are initialized with all -1's
		if(this.table[location] == -1) {
			return true;
		}
		else {
			return false;
		}
	}
	
	/*
	 * Linear probing function that occurs when there is a collision. If there is a collision that occurs when trying
	 * to insert a hash into the hashTable, this will resolve it by finding the next available space in the
	 * hashTable. First, collision counter will increase by 1. It will then look at the next available location 
	 * (location + 1) and see if that position is empty. If it is empty, it will return the empty table locations,
	 * if not, it will repeat the previous steps until it finds an empty spot. 
	 * Every iteration will start by increasing collision counter by 1. 
	 */
	public int linearProbe(int hash, int bucketSize) {
		boolean spotEmpty = false;
		int nextEmpty = -1;
		
		if(bucketSize == 1) {
			// Keep probing until it finds an empty spot
			while(spotEmpty == false) {
				
				// Handle if there are no available slots left in the hash table
				if(this.occupancy >= this.size) {
					return nextEmpty;
				}
				
				// Check if the table[hash] location is empty
				if(isEmpty(hash)) {
					nextEmpty = hash;
					spotEmpty = true;
				}
				else {
					// If the hash == size of the table -1, go back to the beginning of the table and iterate
					if(hash >= this.size - 1) {
//						System.out.println("Collisions at " + hash);
						hash = 0;
					}
					// Iterate hash up by 1
					else {
//						System.out.println("Collisions at " + hash);
						hash += 1;
					}
					this.collisions += 1;
					
				}
			}
		}
		
		/*
		 * Linear probing with a bucket size of 3 is handled by checking the hash location * 3 (i.e. 1 * 3 = slot 3) to get the 
		 * location of the first value of each bucket. If the slot at that location is full, it will check the two slots after
		 * until a empty location is found. If an empty location is not found within the net two slots (the end of the bucket), 
		 * then it will linearly probe to the next hash location and check to see if the bucket has an empty slot. If not, this
		 * process keeps repeating until an empty slot is found.
		 */
		
		if(bucketSize == 3) {
			// This counter is to keep track of the amount of keys stored in a particular bucket
			int stackCount = 1;
			// While spot is full, we probe within the bucket itself in a linear fashion to find an empty space
			while(spotEmpty == false) {
				// Check if our table occupancy is >= 120 to see if there are no available slots and return -1
				if(this.occupancy >= this.size) {
					return nextEmpty;
				}
				// If bucket is full, then we will use a linear probe to search the next bucket
				if(stackCount >= 3) {
					hash = (hash + 1) % 41;
					stackCount = 1;
					this.collisions += 1;
					// Check if hash returns 40, then we must make our hash return 0 because we have no bucket 40
					if(hash == 40) {
						hash = 0;
					}
					// Once we find an empty spot, we return the nextEmpty as the current hash and break out of while loop
					if(isEmpty(hash*3)) {
						nextEmpty = hash*3;
						spotEmpty = true;
					}
					else {
						// Check the bucket + current stackCount to find empty slot within bucket and insert there and break out of while loop
						if(isEmpty(hash*3 + stackCount)) {
							nextEmpty = hash*3 + stackCount;
							spotEmpty = true;
						}
						// Iterate stackCount by 1 to check next slot within bucket
						else {
							stackCount += 1;
						}
					}
				}
				// If the bucket is not full, then we insert into the next empty spot
				else {
					// Check the bucket + current stackCount to find empty slot within bucket and insert there and break out of while loop
					if(isEmpty(hash*3 + stackCount)) {
						nextEmpty = hash*3 + stackCount;
						spotEmpty = true;
					}
					// Iterate stackCount by 1 to check next slot within bucket
					else {
						stackCount += 1;
					}
				}
			}
		}
		return nextEmpty;
	}
	
	/*
	 * Quadratic probing function that occurs when there is a collision. If there is a collision, the hash
	 * will increase by the amount of qProbe squared. Each time qProbe is called, it increases its value by 1,
	 * so the squared values will look as such: 1, 4, 9, 16, etc. If the value of the hash goes above the table size,
	 * the hash will return back to 0 to start over. However, since our table is not of a prime number size, our
	 * quadratic probe may never reach all of the locations
	 */
	public int quadraticProbe(int hash, int bucketSize) {
		int nextEmpty = -1;
		boolean spotEmpty = false;
		int qProbe = 1;
		int tryInsert = hash;
		
		if(bucketSize == 1) {
			while(spotEmpty == false) {
				
				// Handle if there are no available slots left in the hash table
				if(this.occupancy >= this.size) {
					return nextEmpty;
				}
				
				/*
				 *  Since our table size is not a prime number and our table will most likely
				 *  be more than half full, we will not hit every location in the table using this method.
				 *  Instead, once our qProbe has reached the table size, we will switch to linear probing.
				 */

				if(qProbe == this.size) {
					nextEmpty = linearProbe(hash, bucketSize);
					return nextEmpty;
				}
				
				if(isEmpty(tryInsert)) {
					nextEmpty = tryInsert;
					spotEmpty = true;
				}
				
				else {
					// Increase the hash function by the square of the qProbe and then increase qProbe by 1
					tryInsert = (hash + (qProbe*qProbe)) % this.size;
					qProbe += 1;
					this.collisions += 1;
				}
			}
		}
		
		/*
		 * Quadratic probing with a bucket size of 3 works in a similar manner to the linear probe with bucket size of 3.
		 * It will use hash * 3 at first to determine the first slot of each bucket. If it is empty, it will insert at that
		 * location. If not, it will search the bucket linearly first to determine if it has an empty slot or not. If not, 
		 * it will then probe to the next bucket using a function that increases its probe quadratically and searches that next
		 * bucket linearly.
		 */
		if(bucketSize == 3) {
			int stackCount = 1;
			// While spot is full, we probe within the bucket itself in a linear fashion to find an empty space
			while(spotEmpty == false) {
				// Check if our table occupancy is >= 120 to see if there are no available slots and return -1
				if(this.occupancy >= this.size) {
					return nextEmpty;
				}
				// Revert to a linear probe if our qProbe reaches the size of our table to avoid infinite loops
				if(qProbe == this.size) {
					nextEmpty = linearProbe(hash, bucketSize);
					return nextEmpty;
				}
				// If bucket is full, then we will use a linear probe to search the next bucket
				if(stackCount >= 3) {
					tryInsert = (hash + qProbe*qProbe) % 41;
					stackCount = 1;
					qProbe += 1 ;
					this.collisions += 1;
					// Check if hash returns 40, then we must make our hash return 0 because we have no bucket 40
					if(tryInsert == 40) {
						tryInsert = 0;
					}
					// Once we find an empty spot, we return the nextEmpty as the current hash and break out of while loop
					if(isEmpty(tryInsert*3)) {
						nextEmpty = tryInsert*3;
						spotEmpty = true;
					}
					else {
						// Check the bucket + current stackCount to find empty slot within bucket and insert there and break out of while loop
						if(isEmpty(tryInsert*3 + stackCount)) {
							nextEmpty = tryInsert*3 + stackCount;
							spotEmpty = true;
						}
						// Iterate stackCount by 1 to check next slot within bucket
						else {
							stackCount += 1;
						}
					}
				}
				// If the bucket is not full, then we insert into the next empty spot
				else {
					// Check the bucket + current stackCount to find empty slot within bucket and insert there and break out of while loop
					if(isEmpty(tryInsert*3 + stackCount)) {
						nextEmpty = tryInsert*3 + stackCount;
						spotEmpty = true;
					}
					// Iterate stackCount by 1 to check next slot within bucket
					else {
						stackCount += 1;
					}
				}	
			}
		}
		return nextEmpty;
	}
	
	/*
	 * The way I decided to implement chaining is to create a LinkedList within my HashTable class. Because this isn't
	 * "true" chaining, I decided use my LinkedList as a data structure to store all of keys in which a collision occurs.
	 * Once I have parsed through the entire input file, I will then take the each of the items from the LinkedList in a 
	 * FIFO manner to fill in the rest of the HashTable in a linear fashion. It will insert all of the keys stored within
	 * the LinkedList starting from HashTable position 0 till the table size. Once the chaining insertion reaches the end
	 * of the table, then all other keys left in the LinkedList are considered unable to be hashed and are not
	 * inserted into the table at all.
	 */
	public void addKeyToChain(int key) {
		this.linkedList.add(key);
		this.collisions += 1;
	}
	
	public void fillTableFromChain() {
		int i = 0;
		while(this.linkedList.isEmpty() == false) {
			// Check if the entire table has been probed first, if it has, then remove all keys from LL and iterate up failedHashes
			if(i >= this.size) {
				while(this.linkedList.isEmpty() == false) {
					linkedList.removeFirst();
					this.failedHashes += 1;
				}
			}
			// If the entire table has not been probed, continue
			else {
				// if the spot at the table is empty insert the first key stored in linked list and remove from linked list
				if(this.table[i] == -1) {
					int insertKey = this.linkedList.getFirst();
					this.linkedList.removeFirst();
					this.table[i] = insertKey;
					this.occupancy += 1;
					i++;
				}
				// if the spot at the table is full, then we iterate up 1
				else {
					i++;
				}
			}

		}
	}
	
	/*
	 * Hash function that takes in a data input to be hashed and one of the three modulos (or any modulo)
	 * provided by the class requirements. It will hash the input data according to which modulo is
	 * passed and return the hash of the input.
	 */
	public int divHash(int key, int modulo) {
		int hash = 0;
		hash = key % modulo;
		return hash;
	}
	
	/*
	 * Hash function that will hashing input data using a radix-based method. It will take 99999 00000 
	 * 120 positions in the hashTable
	 * It will multiply the hash key by prime number 7, then sum each integer to the ones place, multiply by 2
	 * and subtract from 120.
	 */
	public int myHash(int key) {
		// Use some sort of radix hashing method - inputs are 5 digit long integers
		int hash = 0;
//		System.out.println(key);
		
		key = key * 7;
//		System.out.println(key);
		
		int ones = key % 10;
//		System.out.println(ones);
		
		int tens = (key % 100) / 10;
//		System.out.println(tens);
		
		key = key - tens;
		int hundreds = (key % 1000) / 100;
//		System.out.println(hundreds);
		
		key = key - hundreds;
		int thousands = (key % 10000) / 1000;
//		System.out.println(thousands);
		
		key = key - thousands;
		int tenThousands = (key % 100000) / 10000;
//		System.out.println(tenThousands);
		
		key = key - tenThousands;
		int hundredThousands = (key % 1000000) / 100000;
//		System.out.println(hundredThousands);

		int subtractor = ones + tens + hundreds + thousands + tenThousands + hundredThousands;
//		System.out.println(subtractor);
		
		hash = (120 - 2*subtractor);
		
		// Deal with hash key of 120 when table is 0-119
		if(hash == 120) {
			hash = 0;
		}
//		System.out.println(hash);
		return hash;
	}
	
	/*
	 * This insert function takes in a returned hash value from either divHash or *myHash* and a resolutionValue
	 * (1 = linear, 2 = quadratic, 3 = chaining).
	 * It then inserts the hash key into the hashTable at the hash location specified. If there is already a key 
	 * present at the insertion location, depending on the resolutionValue, it will try to resolve this collision
	 * via one of the three collision resolution methods. Once the resolution method return true, it will insert
	 * the hash value into the table at the specified location of the resolution method. Occupancy will increase
	 * by 1 when this is successful.
	 */
	public void hashInsert(int hashID, int key, int modulo, int resolutionValue, int bucketSize) {
		// Hash the key using provided method or my method. If there is error with method, will return an error due to hash == -1
		int hash = -1;
		if(hashID == 0) {
			hash = divHash(key, modulo);
		}
		else {
			hash = myHash(key);
		}
		try {
			
			// For bucket size == 1
			if(bucketSize == 1) {
				// Check if the insertion location is empty
				boolean spotEmpty = isEmpty(hash);
				if(spotEmpty) {
					// insert key into table if empty
					this.table[hash] = key;
					this.occupancy += 1;
				}
				// If it is not empty, then we proceed to collision handling
				else {
					// Linear probing
					if(resolutionValue == 1) {
						int insertSpot = linearProbe(hash, bucketSize);
						
						// If the hash insertion fails, we add +1 to failedHashes and proceed
						if(insertSpot == -1) {
							this.failedHashes += 1;
						}
						// If hash insertion succeeds
						else {
							this.occupancy += 1;
							this.table[insertSpot] = key;
						}
//						System.out.println("Inserting " + key + " at " + insertSpot);
					}
					// Quadratic probing
					if(resolutionValue == 2) {
						// Quadratic probe
						int insertSpot = quadraticProbe(hash, bucketSize);
						
						// If the hash insertion fails, add +1 to failedHashes and proceed
						if(insertSpot == -1) {
							this.failedHashes += 1;
						}
						else {
							this.occupancy += 1;
							this.table[insertSpot] = key;
						}
					}
					// Chaining
					else {
						// Insert key into the Linked List
						addKeyToChain(key);
					}
				}
			}
			if(bucketSize == 3){
				// Due to our table limitations, if we get a returned modulo hash value of 40, then we set it as equal to 0 and proceed
				if(hash == 40) {
					hash = 0;
				}
				boolean spotEmpty = isEmpty(hash*3);
				
				if(spotEmpty) {
					hash = (hash * 3);
//						System.out.println("Inserting " + key + " at " + hash);
					this.table[hash] = key;		
					this.occupancy += 1;
				}
				else {
					// Linear probing
					if(resolutionValue == 1) {
						int insertSpot = linearProbe(hash, bucketSize);
						
						// If the hash insertion fails, we add +1 to failedHashes and do nothing
						if(insertSpot == -1) {
							this.failedHashes += 1;
//								System.out.println("hash failed at: " + hash);
						}
						// If hash insertion succeeds
						else {
							this.occupancy += 1;
							this.table[insertSpot] = key;
//								System.out.println("Inserting " + key + " at " + insertSpot);
						}
					}
					// Quadratic probing
					if(resolutionValue == 2) {
						// Quadratic probe
						int insertSpot = quadraticProbe(hash, bucketSize);
						
						if(insertSpot == -1) {
							this.failedHashes += 1;
						}
						else {
							this.occupancy += 1;
							
							this.table[insertSpot] = key;
						}
					}
				}	
			}
		}
		
		catch(ArrayIndexOutOfBoundsException ae) {
			System.out.println("Hash is out of bounds. This means some sort of error in calling the hash function has occurred.");
			System.exit(1);
		}
	}
	

}
