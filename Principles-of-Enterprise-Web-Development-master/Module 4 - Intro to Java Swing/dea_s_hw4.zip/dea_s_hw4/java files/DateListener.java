package dea_s_hw4;

import java.util.EventListener;

public interface DateListener extends EventListener{
	public void dateEventOccurred(DateEvent e);
}
