package dea_s_hw4;

import java.util.EventObject;

public class PriceEvent extends EventObject {
	public PriceEvent(Object source) {
		super(source);
	}
}
